// Copy this file to firebase-config.js and replace values with your Firebase Web App config.
// Firebase Console > Project settings > Your apps > Web app > SDK setup.
// This is a client config, not a service-account key. Configure Firestore security rules.
export const firebaseConfig = {
  apiKey: "YOUR_FIREBASE_API_KEY",
  authDomain: "YOUR_PROJECT_ID.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT_ID.firebasestorage.app",
  messagingSenderId: "YOUR_MESSAGING_SENDER_ID",
  appId: "YOUR_FIREBASE_APP_ID"
};
