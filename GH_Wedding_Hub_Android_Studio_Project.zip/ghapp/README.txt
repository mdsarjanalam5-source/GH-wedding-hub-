G.H WEDDING HUB — ANDROID STUDIO SOURCE PROJECT

Open this folder in Android Studio and build the APK using the instructions in ANDROID_BUILD.md.

Cloudinary configuration in the bundled app:
Cloud Name: qarcxthn
Upload Preset: gh_wedding_gallery
Upload Mode: Unsigned

Firebase is not included or required for uploading media to Cloudinary. Cloudinary and Firebase are separate services.

This package is an Android Studio source project, not a prebuilt APK. It has not been compiled or device-tested in this environment.
