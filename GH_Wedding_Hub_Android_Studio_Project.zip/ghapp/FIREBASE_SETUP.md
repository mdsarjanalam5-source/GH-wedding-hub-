# Firebase setup

1. Open https://console.firebase.google.com/ and create a project.
2. Add a Web app and copy its Firebase config.
3. Copy `firebase-config.example.js` to `firebase-config.js`, then replace every `YOUR_...` placeholder.
4. Enable only the Firebase products you need (for shared gallery/reviews, typically Cloud Firestore; for sign-in, Firebase Authentication).
5. Configure Firestore Security Rules and authentication before using real customer data. Never use open read/write rules in production.

**Status:** This package includes Firebase configuration scaffolding only. Firebase is not yet wired into gallery/reviews, so those still use local browser storage until integration is implemented and tested.
