G.H WEDDING HUB — ANDROID STUDIO PROJECT

This is an Android Studio project wrapping the supplied web app in an Android WebView. It is configured with:
- App label: G.H Wedding Hub
- Application ID: com.ghweddinghub.app
- Cloudinary values in the included web app: cloud name qarcxthn, unsigned upload preset gh_wedding_gallery
- Internet permission and Android file picker support for photo/video upload
- No Firebase dependency; Cloudinary is a media upload/CDN service and is not Firebase.

BUILD APK
1. Extract this ZIP.
2. Open the extracted GHWeddingHub folder in Android Studio.
3. Allow Gradle sync and install Android SDK Platform 35 if prompted.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Debug APK output: app/build/outputs/apk/debug/app-debug.apk

NOTES
- This environment did not run an Android Gradle build; build and device-test in Android Studio before distribution.
- The app's existing gallery behavior is whatever is implemented in index.html. Cloudinary unsigned upload is configured, but confirm the preset is enabled for unsigned uploads in Cloudinary.
- For persistent shared gallery listings, the app must retrieve uploaded asset URLs from a data source or Cloudinary API. Cloudinary upload alone does not automatically provide a gallery database.
